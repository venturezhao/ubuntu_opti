taglist
=======

This a Mirror of taglist version 4.6 from http://www.vim.org/scripts/script.php?script_id=273.

Not official github mirror, it's not up-to-date.

For Vundle manage easily.
